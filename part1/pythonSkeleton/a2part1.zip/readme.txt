How to run part one:
python3 a2Part1.py